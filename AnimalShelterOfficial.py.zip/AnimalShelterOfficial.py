from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """

    def __init__(self, username=None, password=None):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:37341'%(username,password))
        self.database = self.client['AAC']

    # Complete this create method to implement the C in CRUD.
    def create(self, data):
        if animal_data is not None:
            print("----------------------- Inserting New Animal ------------------")
            self.database.animals.insert_one(data)  # data should be dictionary
            print("-------------- Done -------------------------------------------")
        else:
            raise Exception("Failed to add Data")
            
    # Complete this read method to implement the R in CRUD.
    def read(self, data):
        if data is not None:
            data = self.database.animals.find(data,{"_id":False}) # data should be dictionary   
            return data
        else:
            raise Exception("nothing to read, hint is empty")
            
            
    # Complete this update method to implement the U in CRUD.
    def update(self, _criteria, new_data):
        if _criteria is not None and _newData is not None:
            self.database.animal.update_many(_criteria,{'$set':new_data}) 
            self.read(new_data)
            
        else:
            raise Exception("please Enter both key and data to modify the collection")
    
    # Complete this delete method to implement to D in CRUD.
    def delete(self, animal):
        if _animal is not None:
            data = self.read(animal) # find animal first
            if data is None:
                print("Animal does not exists")
                return
            self.database.animal.delete_many(animal)  # data should be dictionary 
        else:
            raise Exception("nothing to delete, animal data is empty")
            
